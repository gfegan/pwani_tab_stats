Has all the requirements for day 6

data -- for holding data
docs -- for holding any shared documents/books for day 6
packages -- has all packages required for rfiles in day 6
rfiles - holds all r files for solutions. For githhub platform the solution files for previous lesson are included