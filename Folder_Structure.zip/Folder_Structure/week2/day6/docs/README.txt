 assignment.day6.pdf (assignment day 6)
 assignment.day6.DOC (assignment day 6)

day6_solution.pdf  (solution for day 6_exercise) - -- ONLY FOR GITHUB PLATFORM