 assignment.day8.pdf (assignment day 8)
 assignment.day8.DOC (assignment day 8)

day8_solution.pdf  (solution for day 8_exercise)