Has all the requirements for day 8

data -- for holding data
docs -- for holding any shared documents/books for day 8
packages -- has all packages required for rfiles in day 8
rfiles - holds all r files for solutions. For githhub platform the solution files for previous lesson are included