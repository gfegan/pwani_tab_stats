HAS BOTH TRAINING FILES
day8.L1.r � (the training R file- lesson 1)
day8.L2.r � (the training R File- lesson2)

day8_solution.r (r code  for day 8_exercise) -- ONLY FOR GITHUB PLATFORM