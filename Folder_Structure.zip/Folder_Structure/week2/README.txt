WEEK 2 covers
day6 - Anova
day7 -
day8 -
day9 -
day10