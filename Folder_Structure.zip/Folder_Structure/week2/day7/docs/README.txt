 assignment.day7.pdf (assignment day 7)
 assignment.day7.DOC (assignment day 7)

day7_solution.pdf  (solution for day 7_exercise) -- only on github platform