HAS BOTH TRAINING FILES & SOLUTION FILES
day7.L1.r � (the training R file- lesson 1)
day7.L2.r � (the training R File- lesson2)

day7_solution.r (r code  for day 7_exercise) -- ONLY FOR GITHUB PLATFORM