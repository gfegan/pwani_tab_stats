 assignment.day2.pdf (assignment day 2)
 assignment.day2.DOC (assignment day 2)

day2_solution.pdf  (solution for day 2_exercise)