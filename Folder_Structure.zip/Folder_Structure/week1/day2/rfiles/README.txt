HAS BOTH TRAINING FILES
day2.L1.r � (the training R file- lesson 1)
day2.L2.r � (the training R File- lesson2)

day2_solution.r (r code  for day 2_exercise) -- ONLY FOR GITHUB PLATFORM