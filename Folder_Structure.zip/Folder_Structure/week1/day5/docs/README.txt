 assignment.day5.pdf (assignment day 5)
 assignment.day5.DOC (assignment day 5)

day5_solution.pdf  (solution for day 5_exercise) - -- ONLY FOR GITHUB PLATFORM