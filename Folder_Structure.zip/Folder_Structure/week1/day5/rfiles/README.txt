HAS BOTH TRAINING FILES & SOLUTION FILES
day5.L1.r � (the training R file- lesson 1)
day2.L2.r � (the training R File- lesson2)

day5_solution.r (r code  for day 5_exercise) -- ONLY FOR GITHUB PLATFORM