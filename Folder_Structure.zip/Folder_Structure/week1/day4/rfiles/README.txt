HAS BOTH TRAINING FILES & SOLUTION FILES
day4.L1.r � (the training R file- lesson 1)
day4.L2.r � (the training R File- lesson2)

day4_solution.r (r code  for day 4_exercise) -- ONLY FOR GITHUB PLATFORM