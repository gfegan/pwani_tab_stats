 assignment.day4.pdf (assignment day 4)
 assignment.day4.DOC (assignment day 4)

day4_solution.pdf  (solution for day 4_exercise) - -- ONLY FOR GITHUB PLATFORM