HAS BOTH TRAINING FILES & SOLUTION FILES
day1.L1.r � (the training R file- lesson 1)
day1.L2.r � (the training R File- lesson2)

day1_solution.r (r code  for day 1_exercise) -- ONLY FOR GITHUB PLATFORM