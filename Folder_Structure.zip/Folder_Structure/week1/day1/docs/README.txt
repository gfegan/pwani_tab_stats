 assignment.day1.pdf (assignment day 1)
 assignment.day1.DOC (assignment day 1)

day1_solution.pdf  (solution for day 1_exercise) - -- ONLY FOR GITHUB PLATFORM
