Has all the requirements for day 1

data -- for holding data
docs -- for holding any shared documents/books for day 1
packages -- has all packages required for rfiles in day 1
rfiles - holds all r files for solutions. For githhub platform the solutin files are included
