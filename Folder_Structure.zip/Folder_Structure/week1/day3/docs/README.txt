 assignment.day3.pdf (assignment day 3)
 assignment.day3.DOC (assignment day 3)

day3_solution.pdf  (solution for day 3_exercise) -- only on github platform