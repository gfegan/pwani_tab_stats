HAS BOTH TRAINING FILES & SOLUTION FILES
day3.L1.r � (the training R file- lesson 1)
day3.L2.r � (the training R File- lesson2)

day3_solution.r (r code  for day 3_exercise) -- ONLY FOR GITHUB PLATFORM